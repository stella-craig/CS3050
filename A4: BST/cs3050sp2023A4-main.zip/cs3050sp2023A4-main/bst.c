#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include "bst.h"

// Local functions

// These are stubs.  That is, you need to implement these functions.

BST * NewBST()
{
    return NULL;
}

void TreeInsert(BST * pBST, void * satellite, long long key)
{
}

void InOrder(BST * p, NODEVISITFUNC func)
{
}

void PreOrder(BST * pBST, NODEVISITFUNC func)
{
}


void PostOrder(BST * pBST, NODEVISITFUNC func)
{
}


void * Search(BST * pBST, long long key)
{
    return NULL;
}


void TreeDelete(BST * pBST, long long key)
{
}

